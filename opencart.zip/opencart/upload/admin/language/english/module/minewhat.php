<?php
// Heading
$_['heading_title'] = 'MineWhat Ecommerce Analytics';

// Text
$_['text_module'] = 'Modules';
$_['text_domain_id'] = 'Domain ID';
$_['text_enable'] = 'Enable';

// Options
$_['option_enable'] = 'Enable';
$_['option_disable'] = 'Disable';

// Message
$_['message_enabled'] = 'Success: MineWhat Analytics module enabled!';
$_['message_disabled'] = 'MineWhat Analytics module disabled!';
$_['message_warning'] = 'Please fill the required fields!';

?>
