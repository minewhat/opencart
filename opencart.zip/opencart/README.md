MineWhat Ecommerce Analytics VQmod
------------------------------------

For installation instructions, documentation, and examples please visit:
http://help.minewhat.com/post/94526071286/installing-minewhat-on-your-opencart-store
